<?php
$servername = "127.0.0.1";
$database = "usersdb";
$username = "root";
$password = "";
$dbname="usersdb";
$mysqli = new mysqli($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) { 
    printf("Connect failed: %s\n", mysqli_connect_error()); 
    exit();
}

 ?>