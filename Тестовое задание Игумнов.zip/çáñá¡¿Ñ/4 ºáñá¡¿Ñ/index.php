<!DOCTYPE html>
<html>
    <head>
        <?php require "db.php"; ?>
        <link href="style.css" rel="stylesheet" type="text/css">
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
<h2>Задание №1:</h2>
<TABLE class='tableusers'><TR style='background: rgb(247, 246, 243)'>
<TD><b>id пользователя</b></TD>
<TD><b>Имя</b></TD>
<TD><b>Email</b></TD>
<TD><b>Пароль</b></TD>
<TD><b>Статус</b></TD>
<TD><b>Дата последнего посещения</b></TD>
<TD><b>Дата создания</b></TD>
</TR>
<?php
$tableusersone = $mysqli->query('SELECT objects.Id,name, status,last_login, created, email, password '
        . 'FROM objects INNER JOIN status ON objects.status_id = status.Id JOIN users ON objects.Id = users.object_id '
        . 'WHERE objects.status_id="1" and DATE(created) > "2020-01-01" ORDER BY objects.Id');
while($row = $tableusersone->fetch_object()) {
   echo "<TD>$row->Id</TD>";
   echo "<TD>$row->name</TD>";
   echo "<TD>$row->email</TD>";
   echo "<TD>$row->password</TD>";
   echo "<TD>$row->status</TD>";
   echo "<TD>$row->last_login</TD>";
   echo "<TD>$row->created</TD></TR>";
}
 echo "</TR></TABLE><BR><BR>";
?>

<h2>Задание №2:</h2>
<?php
    if(array_key_exists('button1', $_POST)) {
            button1();
        }
        function button1() {
            global $mysqli;
            $mysqli->query('UPDATE objects SET status_id="1", last_login = "2022-08-25"');
            header("Refresh:0");
        }
?>
<form method="POST">
        <input type="submit" name="button1" class="button" value="Поменять данные" />
    </form>
    </body>
</html>




