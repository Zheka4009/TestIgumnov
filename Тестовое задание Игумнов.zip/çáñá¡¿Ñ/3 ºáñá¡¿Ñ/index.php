<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
	if(!isset($_GET['list']) || !isset($_GET['n'])) {
		echo "Передайте методом GET два параметра:<br/>list - список целочисленных элементов через запятую<br/>n - число, которое нужно найти";
	} else {
	$list = explode(',', $_GET['list']);
	$n = $_GET['n'];
	$start = 0;
	$end = count($list)-1;
	$itercount = 0;
	while(true) {
		$itercount += 1;
		$k = floor(($end + $start) / 2);
		if($list[$k] == $n) {
			echo "list[$k] = $n - Искомое число<br/>Количество итераций: $itercount";
			break;
		}
		if($start == $end) {
			echo "Число не найдено<br/>Количество итераций: $itercount";
			break;
		}
		if($n > $list[$k]) {
			$start = $k + 1;
		}
		if($n < $list[$k]) {
			$end = $k - 1;
		}
	}
        }
?>
    </body>
</html>
