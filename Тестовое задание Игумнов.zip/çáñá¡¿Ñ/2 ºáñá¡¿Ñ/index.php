<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form name="search" method="get">
          <input  required type="text" name="minprice" placeholder="int $minPrice...">
          <input  required type="text" name="maxprice" placeholder="int $maxPrice...">
          <input  required type="text" name="itms" placeholder="array $items...">
    <button name="but">Поиск</button>
  </form>
        
<?php
class Parents {}
interface Single {}
class Singleton extends Parents implements Single {
    private static $_instance = null;
    public static function getInstance() {
        if(is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    private function __construct() {}
    private function __clone() {}
    public static function conclusion($minprice,$maxprice,$items)
    {
        $v=rand(1, $items);
        $razn=$items-$v;
        if ($items>1 and $razn>=1) {
        $sizearr=array('XS','S','XXL','XL','L','M');
        $titlearr=array(1 => 'Футболки',2 => 'Кофты',3 => 'Свитеры',4 => 'Жилеты',5 => 'Майки');
        
        $title_one=array_rand($titlearr,1);
        $rand_title=$titlearr[$title_one];
        for ($id=1;$id<=$razn;$id++){
             $size_one=array_rand($sizearr,1);
             $rand_size=$sizearr[$size_one];
             $pricecen=rand(300, 2500);
                 $bars = new stdClass();
	         $bars->price = $pricecen;
	         $bars->size = $rand_size;
                 $prices[]=$bars;
             }
             $arrLength = count($prices);
             $bar = new stdClass();
             $bar->title = $rand_title;
	     $bar->prices = $prices;
             $prices_one[]=$bar;
             
        for ($id=1;$id<=($v);$id++){
             $size_two=array_rand($sizearr,1);
             $rand_size=$sizearr[$size_two];
             $pricecen=rand(300, 2500);
             $title_two=array_rand($titlearr,1);
             $rand_title=$titlearr[$title_two];
             $bar = new stdClass();
             $bar->title = $rand_title;
	     $bar->price = $pricecen;
	     $bar->size = $rand_size;
             $prices_two[] = $bar;
        }
        $maxprice = (int)$maxprice;
        $minprice = (int)$minprice;
        $itms = array_merge($prices_one, $prices_two);
        foreach ($itms as $key=>$obj) {
            if (isset($obj->prices)) {
                foreach ($obj->prices as $keys=>$obje) {
                    if ($keys==0) {
                      $itms[$obje->price]=$itms[$keys];
                      unset($itms[0]);  
                    }
                    }
            }
            if($key!=0) {
            $itms[$obj->price]=$itms[$key];
            unset($itms[$key]);
            }
                    }
        $new_array = array_filter($itms,function($obj) use ($itms,$minprice,$maxprice,$arrLength) {
            if (isset($obj->prices)) {
                foreach ($obj->prices as $key=>$obje) {
                    if ($key==0) {
                        
                    }
                    if (($obje->price < $minprice) and ($key==0)) {unset($obj->prices[$key]);}
                    if (($obje->price > $maxprice) and ($key==$arrLength-1)) {unset($obj->prices[$key]);}
                } return true;
            }
            if(($obj->price > $minprice) and ($obj->price < $maxprice)) {
            return true;
            }    
        });
        ksort($new_array);
        echo "<pre>";
        print_r($new_array);
        echo "</pre>";
        }
    }
}
    
    if (isset($_GET['but'])) {
        $minprice=$_GET['minprice'];
        $maxprice=$_GET['maxprice'];
        $items=$_GET['itms'];
        $Object = Singleton::getInstance();
        $Object -> conclusion($minprice,$maxprice,$items);
    }
?>
    </body>
</html>
